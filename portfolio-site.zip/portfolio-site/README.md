# Portfolio

Static portfolio with a P. Simon / K.K. Omisha profile switch. No build step.

## Run locally
Open `index.html` in a browser, or run `npx serve .`

## Deploy to Vercel
1. Push this folder to GitHub.
2. In Vercel choose **Add New → Project** and import the repo.
3. Framework Preset: **Other**. Leave build command and output directory empty.
4. Deploy. Or from the terminal: `npx vercel --prod`

## Edit content
All content is in the `<script>` block of `index.html`: the `simon` and `omisha` objects.
Replace each "Add your..." placeholder. Update `your-domain.example` in `robots.txt` and `sitemap.xml`.

## Resume
Create a `resume/` folder with `P-Simon-Resume.pdf` and `KK-Omisha-Resume.pdf`, then remove the click-blocking line for `#resume` in `index.html`.

## original-vite-source/
Your original data and config files. The React components were not included, so that folder cannot build on its own.
