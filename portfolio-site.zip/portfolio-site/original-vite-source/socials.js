export const socials = [
  { id: 'github', label: 'GitHub', url: 'https://github.com/' },
  { id: 'linkedin', label: 'LinkedIn', url: 'https://linkedin.com/' },
  { id: 'instagram', label: 'Instagram', url: 'https://instagram.com/' },
  { id: 'email', label: 'Email', url: 'mailto:you@example.com' }
]
