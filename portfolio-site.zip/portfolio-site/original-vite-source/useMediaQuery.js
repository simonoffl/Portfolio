import { useEffect, useState } from 'react'
export default function useMediaQuery(q) {
  const [m, setM] = useState(() => (typeof window !== 'undefined' ? matchMedia(q).matches : false))
  useEffect(() => { const mq = matchMedia(q), f = () => setM(mq.matches); f(); mq.addEventListener('change', f); return () => mq.removeEventListener('change', f) }, [q])
  return m
}
