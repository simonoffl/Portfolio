// Placeholder copy: replace with your real story. Nothing here is a claimed fact.
export const story = [
  ['How I Started Coding', 'Add your story here.'], ['My First Project', 'Add your story here.'], ['Why I Chose Computer Engineering', 'Add your story here.'],
  ['My Favorite Technology', 'Add your story here.'], ['A Project That Challenged Me', 'Add your story here.'],
  ["What I'm Learning Now", 'Laravel, React, Flutter, cloud deployment, system design and AI integration.'],
  ['Where I Want to Go', 'Add your story here.'], ['What I Want to Build', 'Add your story here.']
].map(([title, text], i) => ({ id: i + 1, title, text }))
