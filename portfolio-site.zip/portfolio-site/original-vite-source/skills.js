// Self-assessed levels (0-100). Keep them honest. Edit freely.
export const skillGroups = {
  Languages: [['Python', 85], ['JavaScript', 80], ['PHP', 80], ['HTML/CSS', 90]],
  Frontend: [['React', 75], ['Responsive design', 85]],
  Backend: [['Laravel', 75], ['Flask', 70], ['Node.js', 70], ['REST APIs', 80]],
  Databases: [['MySQL', 80], ['PostgreSQL', 65], ['MongoDB', 65]],
  Frameworks: [['Flutter', 55], ['FastAPI', 55]],
  Tools: [['Git/GitHub', 85], ['Docker', 55], ['VS Code', 90]],
  Cloud: [['Vercel/Netlify', 75], ['Firebase', 65], ['Supabase', 65], ['Cloudflare', 55]],
  Other: [['Problem solving', 80], ['UI/UX awareness', 70]]
}
export const technologies = ['Python','PHP','Laravel','JavaScript','React','Node.js','HTML','CSS','Flutter','Firebase','Supabase','MySQL','PostgreSQL','MongoDB','Git','GitHub','Docker','Linux','Vercel','Cloudflare']
export const specializations = [
  { icon: 'Code2', title: 'Frontend Development', desc: 'Responsive interfaces that feel fast and look intentional.', tags: ['HTML','CSS','JavaScript','React','Responsive Design','Animations'] },
  { icon: 'Server', title: 'Backend Development', desc: 'APIs and services, from monoliths to realtime systems.', tags: ['Python','PHP','Laravel','Node.js','Flask','FastAPI','REST APIs'] },
  { icon: 'Database', title: 'Database & Cloud', desc: 'Relational, document and hosted data.', tags: ['MySQL','PostgreSQL','MongoDB','Firebase','Supabase','Cloudflare'] },
  { icon: 'Wrench', title: 'Tools & DevOps', desc: 'Version control, containers and deployment.', tags: ['Git','GitHub','Docker','Vercel','Netlify','Linux','VS Code'] }
]
export const learning = ['Laravel','React','Flutter','Cloud Deployment','System Design','AI Integration']
