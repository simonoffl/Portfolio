// CENTRAL THEME FILE: change colors here only.
export const theme = {
  accent: '#7C3AED',
  accent2: '#06B6D4',
  dark: { bg: '#050505', bg2: '#0B0B0B', card: '#111111', border: 'rgba(255,255,255,0.10)', text: '#FFFFFF', muted: '#A1A1AA' },
  light: { bg: '#F6F6F8', bg2: '#FFFFFF', card: '#FFFFFF', border: 'rgba(0,0,0,0.10)', text: '#0A0A0F', muted: '#52525B' }
}
export function applyTheme(mode = 'dark') {
  const r = document.documentElement, t = theme[mode]
  const map = { bg: t.bg, bg2: t.bg2, card: t.card, border: t.border, text: t.text, muted: t.muted, ac: theme.accent, ac2: theme.accent2 }
  Object.entries(map).forEach(([k, v]) => r.style.setProperty('--' + k, v))
  r.dataset.theme = mode
}
