// Colors come from CSS variables set in src/theme.js (single source of truth).
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: { bg: 'var(--bg)', bg2: 'var(--bg2)', card: 'var(--card)', line: 'var(--border)', ink: 'var(--text)', mute: 'var(--muted)', ac: 'var(--ac)', ac2: 'var(--ac2)' },
      fontFamily: { sans: ['ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'], mono: ['ui-monospace', 'Menlo', 'Consolas', 'monospace'] }
    }
  },
  plugins: []
}
