# Abhisheek Mondal: Developer Portfolio

React + Vite + Tailwind CSS + Framer Motion + Lucide. Optional Node/Express/MySQL contact API in `server/`.

## Run the frontend
```bash
npm install
cp .env.example .env     # optional for local dev
npm run dev              # http://localhost:5173
npm run build && npm run preview
```
The site works with no backend. Without `VITE_API_URL`, the contact form offers a prefilled email link.

## Customize
| What | Where |
|---|---|
| Colors (dark/light, accents) | `src/theme.js` |
| Name, bio, email, roles, resume path | `src/config/siteConfig.js` |
| Projects (add/edit/remove) | `src/data/projects.js` |
| Skills and percentages, technology wall | `src/data/skills.js` |
| Experience & education | `src/data/experience.js` |
| Achievements & hero stats | `src/data/achievements.js` |
| Story cards | `src/data/story.js` |
| Social links | `src/data/socials.js` |

Placeholders ("Add your story here.") are intentionally not filled with invented facts.

## Resume
Put your PDF at `public/resume/Abhisheek-Mondal-Resume.pdf`. Until then the Resume buttons are disabled with a notice.

## Project images
Add images to `public/projects/` (use WebP) and set `image` / `screenshots` in `projects.js`, e.g. `/projects/chat.webp`. Missing images fall back to a gradient with initials.

## GitHub activity (optional)
Set `VITE_GITHUB_USERNAME` in `.env`. If unset or the API fails, the section is hidden or shows a short note.

## Contact backend (Node + MySQL)
1. Create a MySQL database and run `server/schema.sql`.
2. In `.env` set `DB_HOST`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`, `CLIENT_ORIGIN` (your site URL).
3. `npm run server` (port 5000). In dev, Vite proxies `/api` to it.
4. In production set `VITE_API_URL` to the deployed API URL before building.

`POST /api/contact` body: `{ name, email, subject, message }`. Returns `{ success, message }` with 400 (validation), 429 (5 requests / 15 min / IP) or 500. A hidden honeypot field blocks simple bots. Secrets live only in `.env` (git-ignored) and the server; the frontend only ever sees `VITE_*` values.

## Deploy
Frontend: Vercel or Netlify (build `npm run build`, output `dist`). Backend: any Node host or VPS. Update the canonical URL, Open Graph URLs, `public/sitemap.xml` and `public/robots.txt` with your real domain, and add `public/og-image.png`.

## Admin-ready structure
All content is plain data modules, so a future admin dashboard can replace them with API calls without touching components. The `contact_messages` table is ready for a message viewer.
