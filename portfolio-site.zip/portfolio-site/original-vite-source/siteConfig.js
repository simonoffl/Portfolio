// Edit personal content here. No component changes needed.
export const siteConfig = {
  name: 'Abhisheek Mondal',
  logo: 'AM',
  roles: ['Full-Stack Developer', 'Python Developer', 'Web Developer', 'Software Developer'],
  location: 'India',
  email: 'you@example.com',
  phone: '',
  bio: 'I build modern web applications, backend systems and software solutions with a focus on performance, usability and scalable architecture.',
  about: "I'm a Diploma in Computer Engineering student who builds complete products: interfaces people enjoy using, APIs that stay predictable, and databases that hold up. I move between PHP/Laravel, Python and JavaScript depending on what the problem needs, and I care about shipping things that are deployed and usable.",
  available: true,
  resumeUrl: '/resume/Abhisheek-Mondal-Resume.pdf',
  apiUrl: import.meta.env.VITE_API_URL || '',
  githubUsername: import.meta.env.VITE_GITHUB_USERNAME || ''
}
