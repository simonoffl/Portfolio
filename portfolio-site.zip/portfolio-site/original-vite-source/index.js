// Contact API: POST /api/contact  (Express + MySQL). Secrets come from .env only.
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import mysql from 'mysql2/promise'

const app = express()
app.set('trust proxy', 1)
app.use(helmet())
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', methods: ['POST'] }))
app.use(express.json({ limit: '10kb' }))

const pool = mysql.createPool({ host: process.env.DB_HOST, database: process.env.DB_DATABASE, user: process.env.DB_USERNAME, password: process.env.DB_PASSWORD, connectionLimit: 5 })

// 5 messages per IP per 15 minutes.
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false,
  handler: (_req, res) => res.status(429).json({ success: false, message: 'Too many messages. Please try again later.' }) })

const clean = s => String(s ?? '').trim()
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/

app.post('/api/contact', limiter, async (req, res) => {
  try {
    const { name, email, subject, message, website } = req.body || {}
    if (clean(website)) return res.json({ success: true, message: 'Message sent successfully' }) // honeypot: silently drop bots
    const errors = {}
    if (!clean(name) || clean(name).length > 100) errors.name = 'Name is required (max 100 characters).'
    if (!EMAIL.test(clean(email)) || clean(email).length > 150) errors.email = 'A valid email is required.'
    if (!clean(subject) || clean(subject).length > 150) errors.subject = 'Subject is required (max 150 characters).'
    if (clean(message).length < 10 || clean(message).length > 5000) errors.message = 'Message must be 10 to 5000 characters.'
    if (Object.keys(errors).length) return res.status(400).json({ success: false, message: 'Validation failed', errors })
    await pool.execute('INSERT INTO contact_messages (name, email, subject, message, ip) VALUES (?, ?, ?, ?, ?)', [clean(name), clean(email), clean(subject), clean(message), req.ip])
    res.json({ success: true, message: 'Message sent successfully' })
  } catch (err) {
    console.error('contact error:', err.code || err.message) // never leak stack traces to clients
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again later.' })
  }
})

app.get('/api/health', (_req, res) => res.json({ ok: true }))
app.listen(process.env.PORT || 5000, () => console.log('API listening'))
