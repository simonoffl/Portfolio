export const fadeUp = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] } } }
export const fadeLeft = { hidden: { opacity: 0, x: -28 }, show: { opacity: 1, x: 0, transition: { duration: 0.55 } } }
export const scaleIn = { hidden: { opacity: 0, scale: 0.94 }, show: { opacity: 1, scale: 1, transition: { duration: 0.45 } } }
export const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } }
export const viewport = { once: true, margin: '-60px' }
