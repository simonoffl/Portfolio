export const experience = [
  { date: '2026 – Present', role: 'Full-Stack / Software Development', org: 'Personal & freelance projects', description: 'Building web applications, backend systems and software projects.', tech: ['Laravel', 'React', 'Python'] },
  { date: '2025 – Present', role: 'Academic Development', org: 'Diploma in Computer Engineering', description: 'Core computing foundation with hands-on project work alongside.', tech: ['Programming', 'Databases', 'Networks'] },
  { date: 'Ongoing', role: 'Personal Projects', org: 'Self-directed', description: 'Multiple web, backend and application projects shipped end to end.', tech: ['Flask', 'Node.js', 'Flutter'] }
]
export const education = {
  course: 'Diploma in Computer Engineering (DCE)', college: 'Debarit', department: 'Computer Engineering', year: 'Add your year here',
  technologies: ['Programming', 'Databases', 'Web development', 'Networking'], projects: ['Final year project', 'Web and mobile projects listed above']
}
