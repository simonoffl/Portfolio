import { useEffect, useState } from 'react'
// Returns scroll percent, a "scrolled" flag, and the id of the section currently in view.
export default function useScrollProgress(ids = []) {
  const [s, setS] = useState({ progress: 0, scrolled: false, active: ids[0] })
  const key = ids.join()
  useEffect(() => {
    let raf = 0
    const calc = () => {
      raf = 0
      const h = document.documentElement.scrollHeight - innerHeight
      let active = ids[0]
      ids.forEach(id => { const el = document.getElementById(id); if (el && el.getBoundingClientRect().top < innerHeight * 0.4) active = id })
      setS({ progress: h > 0 ? (scrollY / h) * 100 : 0, scrolled: scrollY > 20, active })
    }
    const on = () => { if (!raf) raf = requestAnimationFrame(calc) }
    calc(); addEventListener('scroll', on, { passive: true })
    return () => { removeEventListener('scroll', on); cancelAnimationFrame(raf) }
  }, [key])
  return s
}
