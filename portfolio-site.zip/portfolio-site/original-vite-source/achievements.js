// Replace placeholders with real entries. Items with placeholder:true render in italics.
export const achievements = [
  { title: 'Projects Built', text: '6 featured projects, with more in the works.' },
  { title: 'Technical Skills', text: '20 technologies across the full stack.' },
  { title: 'Academic Milestones', text: 'Diploma in Computer Engineering, in progress.' },
  { title: 'Certifications', text: 'Add your certification here', placeholder: true },
  { title: 'Hackathons', text: 'Add your hackathon here', placeholder: true },
  { title: 'Open Source', text: 'Add your contribution here', placeholder: true }
]
export const stats = [{ value: 6, suffix: '+', label: 'Featured projects' }, { value: 20, suffix: '+', label: 'Technologies' }, { value: 3, suffix: '+', label: 'Backend stacks' }, { value: 100, suffix: '%', label: 'Passion for development' }]
